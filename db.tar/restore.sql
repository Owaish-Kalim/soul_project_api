--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)
-- Dumped by pg_dump version 10.12 (Ubuntu 10.12-0ubuntu0.18.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.team DROP CONSTRAINT team_pkey;
ALTER TABLE ONLY public.team DROP CONSTRAINT "team_Password_key";
ALTER TABLE ONLY public.team DROP CONSTRAINT "team_Mobile_No._key";
ALTER TABLE ONLY public.slh_teams DROP CONSTRAINT slh_teams_pkey;
ALTER TABLE ONLY public.slh_teams DROP CONSTRAINT "slh_teams_MobileNo_key";
ALTER TABLE ONLY public.slh_teams DROP CONSTRAINT "slh_teams_Email_key";
ALTER TABLE public.team ALTER COLUMN "Team_ID" DROP DEFAULT;
ALTER TABLE public.slh_teams ALTER COLUMN "TeamId" DROP DEFAULT;
DROP SEQUENCE public."team_Team_ID_seq";
DROP TABLE public.team;
DROP SEQUENCE public."slh_teams_TeamId_seq";
DROP TABLE public.slh_teams;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: slh_teams; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.slh_teams (
    "TeamId" integer NOT NULL,
    "Email" character varying(50) NOT NULL,
    "FirstName" character varying(50) NOT NULL,
    "LastName" character varying(50) NOT NULL,
    "MobileNo" character varying(10) NOT NULL,
    "Address" character varying(50) NOT NULL,
    "CreatedAt" timestamp without time zone NOT NULL,
    "JoiningDate" timestamp without time zone,
    "Status" character varying(50) NOT NULL,
    "Password" text NOT NULL,
    "Token" text
);


ALTER TABLE public.slh_teams OWNER TO postgres;

--
-- Name: slh_teams_TeamId_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."slh_teams_TeamId_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."slh_teams_TeamId_seq" OWNER TO postgres;

--
-- Name: slh_teams_TeamId_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."slh_teams_TeamId_seq" OWNED BY public.slh_teams."TeamId";


--
-- Name: team; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.team (
    "Team_ID" integer NOT NULL,
    "First_Name" character varying(50) NOT NULL,
    "Last_Name" character varying(50) NOT NULL,
    "Mobile_No." character varying(10) NOT NULL,
    "Address" character varying(50) NOT NULL,
    "Created_At" timestamp without time zone NOT NULL,
    "Joining_At" timestamp without time zone,
    "Status" character varying(50) NOT NULL,
    "Password" text NOT NULL
);


ALTER TABLE public.team OWNER TO postgres;

--
-- Name: team_Team_ID_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."team_Team_ID_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."team_Team_ID_seq" OWNER TO postgres;

--
-- Name: team_Team_ID_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."team_Team_ID_seq" OWNED BY public.team."Team_ID";


--
-- Name: slh_teams TeamId; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slh_teams ALTER COLUMN "TeamId" SET DEFAULT nextval('public."slh_teams_TeamId_seq"'::regclass);


--
-- Name: team Team_ID; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team ALTER COLUMN "Team_ID" SET DEFAULT nextval('public."team_Team_ID_seq"'::regclass);


--
-- Data for Name: slh_teams; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.slh_teams ("TeamId", "Email", "FirstName", "LastName", "MobileNo", "Address", "CreatedAt", "JoiningDate", "Status", "Password", "Token") FROM stdin;
\.
COPY public.slh_teams ("TeamId", "Email", "FirstName", "LastName", "MobileNo", "Address", "CreatedAt", "JoiningDate", "Status", "Password", "Token") FROM '$$PATH$$/2930.dat';

--
-- Data for Name: team; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.team ("Team_ID", "First_Name", "Last_Name", "Mobile_No.", "Address", "Created_At", "Joining_At", "Status", "Password") FROM stdin;
\.
COPY public.team ("Team_ID", "First_Name", "Last_Name", "Mobile_No.", "Address", "Created_At", "Joining_At", "Status", "Password") FROM '$$PATH$$/2928.dat';

--
-- Name: slh_teams_TeamId_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."slh_teams_TeamId_seq"', 16, true);


--
-- Name: team_Team_ID_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."team_Team_ID_seq"', 1, false);


--
-- Name: slh_teams slh_teams_Email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slh_teams
    ADD CONSTRAINT "slh_teams_Email_key" UNIQUE ("Email");


--
-- Name: slh_teams slh_teams_MobileNo_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slh_teams
    ADD CONSTRAINT "slh_teams_MobileNo_key" UNIQUE ("MobileNo");


--
-- Name: slh_teams slh_teams_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.slh_teams
    ADD CONSTRAINT slh_teams_pkey PRIMARY KEY ("TeamId");


--
-- Name: team team_Mobile_No._key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT "team_Mobile_No._key" UNIQUE ("Mobile_No.");


--
-- Name: team team_Password_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT "team_Password_key" UNIQUE ("Password");


--
-- Name: team team_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.team
    ADD CONSTRAINT team_pkey PRIMARY KEY ("Team_ID");


--
-- PostgreSQL database dump complete
--

